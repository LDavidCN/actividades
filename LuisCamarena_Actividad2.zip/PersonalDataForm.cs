namespace Actividad2;

public sealed class PersonalDataForm : Form
{
    private readonly TextBox firstName = Ui.TextBox();
    private readonly TextBox lastName = Ui.TextBox();
    private readonly TextBox address = Ui.TextBox(true);
    private readonly TextBox city = Ui.TextBox();
    private readonly ComboBox civilStatus = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 260 };

    public PersonalDataForm()
    {
        Ui.Configure(this, "Datos personales");
        Size = new Size(850, 650);
        Controls.Add(Ui.Header("Datos personales", "Completa la información solicitada"));
        civilStatus.Items.AddRange(["Soltero(a)", "Casado(a)", "Divorciado(a)", "Viudo(a)"]);

        var form = new TableLayoutPanel { Location = new Point(65, 125), Size = new Size(510, 320), ColumnCount = 2, RowCount = 5, BackColor = Color.White, Padding = new Padding(24) };
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39));
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 61));
        AddRow(form, 0, "Nombre:", firstName);
        AddRow(form, 1, "Apellido:", lastName);
        AddRow(form, 2, "Dirección:", address);
        AddRow(form, 3, "Ciudad:", city);
        AddRow(form, 4, "Estado civil:", civilStatus);
        Controls.Add(form);

        var presentation = new Panel { Location = new Point(605, 125), Size = new Size(170, 320), BackColor = Ui.Navy };
        presentation.Paint += (_, e) =>
        {
            e.Graphics.FillEllipse(Brushes.White, 45, 48, 80, 80);
            using var font = new Font("Segoe UI", 44, FontStyle.Bold);
            e.Graphics.DrawString("☺", font, Brushes.White, 45, 150);
        };
        presentation.Controls.Add(new Label { Text = "Tu perfil", ForeColor = Color.White, Font = new Font("Segoe UI", 14, FontStyle.Bold), AutoSize = true, Location = new Point(42, 260) });
        Controls.Add(presentation);
        Controls.Add(Ui.Button("Guardar datos", new Point(342, 480), (_, _) => Save()));
        Controls.Add(Ui.Button("Cuestionario médico", new Point(65, 480), (_, _) => new MedicalForm().ShowDialog(this)));
        Controls.Add(Ui.Button("Regresar", new Point(600, 480), (_, _) => Close(), Color.SlateGray));
    }

    private static void AddRow(TableLayoutPanel panel, int row, string label, Control input)
    {
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
        panel.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Font = new Font("Segoe UI", 10, FontStyle.Bold) }, 0, row);
        input.Anchor = AnchorStyles.Left;
        panel.Controls.Add(input, 1, row);
    }

    private void Save()
    {
        if (string.IsNullOrWhiteSpace(firstName.Text) || string.IsNullOrWhiteSpace(lastName.Text) || civilStatus.SelectedIndex < 0)
        {
            MessageBox.Show("Completa al menos nombre, apellido y estado civil.", "Datos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        MessageBox.Show("Los datos personales se registraron correctamente.", "Registro", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
