namespace Actividad2;

public sealed class LoginForm : Form
{
    private const string AccessPassword = "A2CSharp";
    private readonly TextBox password = Ui.TextBox();

    public LoginForm()
    {
        Ui.Configure(this, "Acceso al sistema");
        Size = new Size(560, 420);
        Controls.Add(Ui.Header("Acceso al sistema", "Actividad 2 · Lenguajes de Programación III"));

        var card = new Panel { BackColor = Color.White, Size = new Size(390, 190), Location = new Point(78, 135), BorderStyle = BorderStyle.FixedSingle };
        card.Controls.Add(new Label { Text = "Contraseña de acceso", Font = new Font("Segoe UI", 12, FontStyle.Bold), AutoSize = true, Location = new Point(35, 28) });
        password.Location = new Point(35, 66);
        password.Width = 315;
        password.UseSystemPasswordChar = true;
        password.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) Authenticate(); };
        card.Controls.Add(password);
        card.Controls.Add(Ui.Button("Ingresar", new Point(225, 115), (_, _) => Authenticate()));
        card.Controls.Add(new Label { Text = "Clave de demostración: A2CSharp", ForeColor = Color.DimGray, AutoSize = true, Location = new Point(35, 128) });
        Controls.Add(card);
    }

    private void Authenticate()
    {
        if (password.Text == AccessPassword)
        {
            Hide();
            using var main = new MainForm();
            main.ShowDialog();
            Close();
            return;
        }
        MessageBox.Show("La contraseña no es correcta.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        password.SelectAll();
        password.Focus();
    }
}
