namespace Actividad2;

public sealed class GreetingForm : Form
{
    private readonly TextBox name = Ui.TextBox();

    public GreetingForm()
    {
        Ui.Configure(this, "Saludo");
        Size = new Size(720, 480);
        Controls.Add(Ui.Header("Formulario de saludo", "Ingresa tu nombre para recibir un mensaje personalizado"));
        var content = new Panel { BackColor = Color.White, Location = new Point(110, 145), Size = new Size(480, 200), BorderStyle = BorderStyle.FixedSingle };
        content.Controls.Add(new Label { Text = "Ingresa tu nombre:", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(55, 40) });
        name.Location = new Point(55, 76);
        name.Width = 370;
        content.Controls.Add(name);
        content.Controls.Add(Ui.Button("Saludar", new Point(305, 125), (_, _) => Greet()));
        Controls.Add(content);
    }

    private void Greet()
    {
        var person = name.Text.Trim();
        if (string.IsNullOrWhiteSpace(person))
        {
            MessageBox.Show("Escribe tu nombre antes de continuar.", "Dato requerido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            name.Focus();
            return;
        }
        MessageBox.Show($"{person}, ¡bienvenido(a) a la aplicación!", "Saludo", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
