using System.Globalization;

namespace Actividad2;

public sealed class OperationsForm : Form
{
    private readonly TextBox[] values = Enumerable.Range(1, 6).Select(_ => Ui.TextBox()).ToArray();
    private readonly Label result = new() { AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI", 14, FontStyle.Bold), ForeColor = Ui.Navy, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

    public OperationsForm()
    {
        Ui.Configure(this, "Operaciones básicas");
        Size = new Size(900, 660);
        Controls.Add(Ui.Header("Operaciones básicas", "Ingresa seis números diferentes y elige la operación que deseas realizar"));
        var grid = new TableLayoutPanel { Location = new Point(75, 125), Size = new Size(360, 300), ColumnCount = 2, RowCount = 6, BackColor = Color.White, Padding = new Padding(25) };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        for (var i = 0; i < values.Length; i++)
        {
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / values.Length));
            grid.Controls.Add(new Label { Text = $"Número {i + 1}:", AutoSize = true, Anchor = AnchorStyles.Left, Font = new Font("Segoe UI", 10, FontStyle.Bold) }, 0, i);
            values[i].Width = 175;
            values[i].Anchor = AnchorStyles.Left;
            grid.Controls.Add(values[i], 1, i);
        }
        Controls.Add(grid);

        var actions = new FlowLayoutPanel { Location = new Point(480, 140), Size = new Size(280, 220), FlowDirection = FlowDirection.TopDown, WrapContents = false };
        actions.Controls.Add(Ui.Button("Suma", (_, _) => Calculate(numbers => numbers.Sum())));
        actions.Controls.Add(Ui.Button("Resta", (_, _) => Calculate(numbers => numbers.Skip(1).Aggregate(numbers[0], (total, number) => total - number))));
        actions.Controls.Add(Ui.Button("Multiplicación", (_, _) => Calculate(numbers => numbers.Aggregate(1D, (total, number) => total * number))));
        actions.Controls.Add(Ui.Button("División", (_, _) => Calculate(Divide)));
        var clearButton = Ui.Button("Limpiar", (_, _) => Clear());
        clearButton.BackColor = Color.FromArgb(180, 83, 9);
        actions.Controls.Add(clearButton);
        var backButton = Ui.Button("Regresar", (_, _) => Close());
        backButton.BackColor = Color.SlateGray;
        actions.Controls.Add(backButton);
        Controls.Add(actions);
        result.Location = new Point(75, 470);
        result.Size = new Size(685, 70);
        result.Text = "Resultado: —";
        Controls.Add(result);
    }

    private void Calculate(Func<double[], double> operation)
    {
        if (!TryGetValues(out var numbers)) return;
        try
        {
            result.Text = $"Resultado: {operation(numbers):N2}";
        }
        catch (DivideByZeroException)
        {
            MessageBox.Show("No es posible dividir entre cero.", "Operación no válida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private static double Divide(double[] numbers)
    {
        var total = numbers[0];
        foreach (var number in numbers.Skip(1))
        {
            if (number == 0) throw new DivideByZeroException();
            total /= number;
        }
        return total;
    }

    private bool TryGetValues(out double[] numbers)
    {
        numbers = new double[values.Length];
        for (var i = 0; i < values.Length; i++)
        {
            if (!double.TryParse(values[i].Text, NumberStyles.Float, CultureInfo.CurrentCulture, out numbers[i]))
            {
                MessageBox.Show($"Escribe un número válido en el campo Número {i + 1}.", "Dato no válido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                values[i].Focus();
                return false;
            }
        }
        return true;
    }

    private void Clear()
    {
        foreach (var value in values) value.Clear();
        result.Text = "Resultado: —";
        values[0].Focus();
    }
}
