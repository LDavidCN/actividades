using System.Drawing.Drawing2D;

namespace Actividad2;

internal static class Ui
{
    public static readonly Color Navy = Color.FromArgb(22, 52, 92);
    public static readonly Color Blue = Color.FromArgb(37, 99, 235);
    public static readonly Color Light = Color.FromArgb(241, 245, 249);

    public static void Configure(Form form, string title)
    {
        form.Text = title + " | Universidad";
        form.StartPosition = FormStartPosition.CenterScreen;
        form.BackColor = Light;
        form.Font = new Font("Segoe UI", 10F);
        form.Icon = SystemIcons.Shield;
        form.MinimumSize = new Size(720, 480);
    }

    public static Panel Header(string title, string subtitle)
    {
        var panel = new Panel { Dock = DockStyle.Top, Height = 92, BackColor = Navy };
        panel.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var brush = new SolidBrush(Color.FromArgb(70, Color.White));
            e.Graphics.FillEllipse(brush, 18, 17, 58, 58);
            using var font = new Font("Segoe UI", 25, FontStyle.Bold);
            e.Graphics.DrawString("U", font, Brushes.White, 30, 24);
        };
        panel.Controls.Add(new Label { Text = title, ForeColor = Color.White, Font = new Font("Segoe UI", 19, FontStyle.Bold), AutoSize = true, Location = new Point(92, 20) });
        panel.Controls.Add(new Label { Text = subtitle, ForeColor = Color.FromArgb(210, 225, 245), AutoSize = true, Location = new Point(94, 56) });
        return panel;
    }

    public static Button Button(string text, EventHandler? click = null)
    {
        var button = new Button { Text = text, AutoSize = true, BackColor = Blue, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Padding = new Padding(14, 7, 14, 7), Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        if (click is not null) button.Click += click;
        return button;
    }

    public static Button Button(string text, Point location, EventHandler click, Color? background = null)
    {
        var button = Button(text, click);
        button.Location = location;
        if (background.HasValue) button.BackColor = background.Value;
        return button;
    }

    public static TextBox TextBox(bool multiline = false) => new()
    {
        Width = 260,
        Multiline = multiline,
        Height = multiline ? 58 : 30,
        BorderStyle = BorderStyle.FixedSingle
    };
}
