namespace Actividad2;

public sealed class MainForm : Form
{
    public MainForm()
    {
        Ui.Configure(this, "Menú principal");
        Size = new Size(860, 560);
        var menu = new MenuStrip { BackColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
        menu.Items.Add("Saludo", null, (_, _) => new GreetingForm().ShowDialog(this));
        menu.Items.Add("Datos Personales", null, (_, _) => new PersonalDataForm().ShowDialog(this));
        menu.Items.Add("Operaciones Básicas", null, (_, _) => new OperationsForm().ShowDialog(this));
        menu.Items.Add("Salir", null, (_, _) => Close());
        MainMenuStrip = menu;
        Controls.Add(menu);
        Controls.Add(Ui.Header("Menú principal", "Selecciona una opción para comenzar"));

        var text = new Label
        {
            Text = "Bienvenido(a)\n\nEsta aplicación integra controles, menús funcionales y formularios de Windows Forms.",
            Font = new Font("Segoe UI", 14), AutoSize = false, TextAlign = ContentAlignment.MiddleCenter,
            Size = new Size(640, 125), Location = new Point(105, 165), ForeColor = Ui.Navy
        };
        Controls.Add(text);
        var actions = new FlowLayoutPanel { Location = new Point(170, 325), Size = new Size(520, 65), FlowDirection = FlowDirection.LeftToRight };
        actions.Controls.Add(Ui.Button("Saludo", (_, _) => new GreetingForm().ShowDialog(this)));
        actions.Controls.Add(Ui.Button("Datos personales", (_, _) => new PersonalDataForm().ShowDialog(this)));
        actions.Controls.Add(Ui.Button("Operaciones", (_, _) => new OperationsForm().ShowDialog(this)));
        Controls.Add(actions);
    }
}
