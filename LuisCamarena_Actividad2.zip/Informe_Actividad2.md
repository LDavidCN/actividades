# Actividad 2: Creación de Interfaces

**Asignatura:** Lenguajes de Programación III (C#)  
**Estudiante:** Nombre Apellido  
**Fecha:** 26 de julio de 2026  

## Desarrollo

### Entorno de trabajo

La aplicación fue desarrollada en Visual Studio mediante Windows Forms y el lenguaje C#. Se utilizó .NET 8 para Windows. El proyecto integra formularios, etiquetas, cuadros de texto, botones, menú, cuadros combinados, botones de opción y cuadros de mensaje.

### Ejecución del programa

Al iniciar se muestra un formulario de acceso que solicita una contraseña. Para la demostración se usa `A2CSharp`. Después del acceso se presenta un menú funcional con las opciones Saludo, Datos Personales, Operaciones Básicas y Salir.

El formulario Saludo solicita el nombre y muestra un mensaje personalizado. Datos Personales permite capturar nombre, apellido, dirección, ciudad y estado civil. Desde ese formulario se abre el cuestionario médico, que contiene cinco preguntas con listas de opciones y botones Sí/No para depresión.

Operaciones Básicas solicita seis números y permite realizar suma, resta, multiplicación y división; también incluye los botones Limpiar y Regresar. La aplicación valida que los valores sean números y evita la división entre cero.

## Enlace del código

Pega aquí el enlace del repositorio de GitHub después de publicarlo: `https://github.com/usuario/Actividad2`
