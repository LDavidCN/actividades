# Actividad 2 — Creación de interfaces

Proyecto de Windows Forms en C# que cumple con la actividad solicitada:

- Menú funcional con Saludo, Datos Personales, Operaciones Básicas y Salir.
- Formulario de acceso por contraseña.
- Formularios con identidad visual de Universidad.
- Captura de datos personales y cuestionario médico de cinco preguntas.
- Operaciones de suma, resta, multiplicación, división, limpiar y regresar con seis números.

## Ejecución

1. Abrir `Actividad2.csproj` en Visual Studio.
2. Ejecutar el proyecto.
3. Usar la contraseña de demostración: `A2CSharp`.

## Entrega solicitada en el PDF

- Documento PDF: `NombreApellido_A2`, con portada, desarrollo, entorno de trabajo y ejecución del programa.
- Proyecto comprimido: `NombreApellido_Actividad2.zip`.
- Agregar al documento PDF el enlace del repositorio de GitHub después de publicarlo.

> El nombre de archivo y el enlace de GitHub se dejan pendientes porque dependen de los datos y la cuenta del estudiante.
