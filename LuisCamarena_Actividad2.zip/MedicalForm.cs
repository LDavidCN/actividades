namespace Actividad2;

public sealed class MedicalForm : Form
{
    public MedicalForm()
    {
        Ui.Configure(this, "Cuestionario médico");
        Size = new Size(800, 600);
        Controls.Add(Ui.Header("Cuestionario médico", "Responde las cinco preguntas solicitadas"));
        var table = new TableLayoutPanel { Location = new Point(55, 125), Size = new Size(670, 310), ColumnCount = 2, RowCount = 5, BackColor = Color.White, Padding = new Padding(22) };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38));
        AddQuestion(table, 0, "¿Padeces de alguna enfermedad?", ["Ninguna", "Diabetes", "Hipertensión", "Asma", "Otra"]);
        AddQuestion(table, 1, "¿Tienes alergias?", ["Ninguna", "Alimentos", "Medicamentos", "Polen", "Otra"]);
        AddQuestion(table, 2, "¿Alguna vez te han operado?", ["No", "Sí, cirugía menor", "Sí, cirugía mayor"]);
        AddQuestion(table, 3, "¿Haces ejercicio?", ["No", "1 a 2 días", "3 a 5 días", "Diariamente"]);
        table.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
        table.Controls.Add(new Label { Text = "¿Padeces de depresión?", AutoSize = true, Anchor = AnchorStyles.Left, Font = new Font("Segoe UI", 10, FontStyle.Bold) }, 0, 4);
        var depression = new FlowLayoutPanel { AutoSize = true, Anchor = AnchorStyles.Left };
        depression.Controls.Add(new RadioButton { Text = "Sí", AutoSize = true });
        depression.Controls.Add(new RadioButton { Text = "No", AutoSize = true, Checked = true });
        table.Controls.Add(depression, 1, 4);
        Controls.Add(table);
        Controls.Add(Ui.Button("Guardar respuestas", new Point(460, 465), (_, _) => MessageBox.Show("Respuestas guardadas.", "Cuestionario médico", MessageBoxButtons.OK, MessageBoxIcon.Information)));
        Controls.Add(Ui.Button("Regresar", new Point(300, 465), (_, _) => Close(), Color.SlateGray));
    }

    private static void AddQuestion(TableLayoutPanel panel, int row, string question, string[] options)
    {
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
        panel.Controls.Add(new Label { Text = question, AutoSize = true, Anchor = AnchorStyles.Left, Font = new Font("Segoe UI", 10, FontStyle.Bold) }, 0, row);
        var combo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 215, Anchor = AnchorStyles.Left };
        combo.Items.AddRange(options);
        panel.Controls.Add(combo, 1, row);
    }
}
